<?php
	
	 class Producto
    {
        public $nombre;
        public $url;
		public $imagen;
		public $precio;
        
    }


?>